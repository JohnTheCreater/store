const mysql=require('mysql')
const util=require('util')

const pool=mysql.createPool({

    host:'localhost',
    user:'rssdinfo_john',
    password:'john@123',
    database:'rssdinfo_john'

    // user:'rssdinfo_john@localhost',
    // password:'john@123',
    // database:'rssdinfo_john'
    
});

pool.query= util.promisify(pool.query)


module.exports=pool