const express=require('express')
const route=require('./route')
const cors=require('cors')
const app=express()
const path= require('path')

app.use(cors());
app.use(express.json())
app.use('/api',route);
app.use(express.static(path.join(__dirname, '../build')));
app.listen(2000,()=>{
    console.log("server is running  on port 2000");
});

